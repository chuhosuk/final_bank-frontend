import { Component } from "react";


class NoticeAddComponent extends Component{
    render(){
        return(
            <div>
                <h1> 공지사항 등록 폼 </h1>
                <div>
                    <form>


                    </form>
                </div>
            </div>
        )
    }
}
export default NoticeAddComponent;