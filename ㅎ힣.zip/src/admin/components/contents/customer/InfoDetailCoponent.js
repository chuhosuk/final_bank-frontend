import { Component } from "react";

class InfoDetailComponent extends Component{
    render(){
        return(
            <div>
                <h1>회원정보 상세페이지</h1>
                <div>
                    

                </div>
            </div>
        )
    }
}
export default InfoDetailComponent;