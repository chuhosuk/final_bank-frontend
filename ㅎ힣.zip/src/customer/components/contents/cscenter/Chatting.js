// 채팅상담
import React from "react";
import chatting from '../../../../customer/resources/img/5-2.png';

function Chatting () {
    return (
        <div className="container">
            <img src={chatting} alt="face" />
            <br/>
            <br/>
            <br/>
        </div>
    )
}
export default Chatting;