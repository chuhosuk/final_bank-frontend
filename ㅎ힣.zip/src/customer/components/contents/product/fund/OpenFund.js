// 펀드 상품 > 펀드 계좌개설
import React from "react";
import openfund from '../../../../../customer/resources/img/3-56.png';

function OpenFund () {
    return (
        <div className="container">
            <img src={openfund} alt="" />
        </div>
    )
}
export default OpenFund;