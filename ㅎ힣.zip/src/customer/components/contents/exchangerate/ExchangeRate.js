// 환율
import React from "react";
import ex_rate from '../../../../customer/resources/img/4-1.png';

function ExchangeRate () {
    return (
        <div className="container">
            <img src={ex_rate} alt="" />
            <br/>
            <br/>
            <br/>
        </div>
    )
}
export default ExchangeRate;