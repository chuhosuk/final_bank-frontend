// 환율계산기
import React from "react";
import ex_rateCal from '../../../../customer/resources/img/4-2.png';

function ExchangeRateCal () {
    return (
        <div className="container">
            <img src={ex_rateCal} alt="" />
            <br/>
            <br/>
            <br/>
        </div>
    )
}
export default ExchangeRateCal;